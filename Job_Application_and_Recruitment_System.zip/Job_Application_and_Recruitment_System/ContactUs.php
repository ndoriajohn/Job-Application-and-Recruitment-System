
<html>
<head>
    
    
    <title>Job Application and Recruitment</title>
    <meta name="description" content="..." />
    <meta name="keywords" content="..." />
    
    <link rel="index" href="./" title="Home" />
    <link rel="stylesheet" media="screen,projection" type="text/css" href="./css/main.css" />
    <link rel="stylesheet" media="print" type="text/css" href="./css/print.css" />
    <link rel="stylesheet" media="aural" type="text/css" href="./css/aural.css" />
    <style type="text/css">
<!--
.style1 {
	color: #000045;
	font-weight: bold;
}
-->
    </style>
    <script src="SpryAssets/SpryValidationTextarea.js" type="text/javascript"></script>
    <link href="SpryAssets/SpryValidationTextarea.css" rel="stylesheet" type="text/css" />
</head>

<body id="www-url-cz">
<!-- Main -->
<div id="main" class="box">
<?php 
include "Header.php"
?>
<?php 
include "Menu.php"
?>   
<!-- Page (2 columns) -->
    <div id="page" class="box">
    <div id="page-in" class="box">

        <div id="strip" class="box noprint">

            <!-- RSS feeds -->
            <hr class="noscreen" />

            <!-- Breadcrumbs -->
            <p id="breadcrumbs">&nbsp;</p>
          <hr class="noscreen" />
            
        </div> <!-- /strip -->

        <!-- Content -->
        <div id="content">

           
            <!-- /article -->

            <hr class="noscreen" />

           
            <!-- /article -->

            <hr class="noscreen" />
            
            <!-- Article -->
           
            <!-- /article -->

            <hr class="noscreen" />

            <!-- Article -->
            <div class="article">
                <h2><span><a href="#">Contact Us</a></span></h2>
               

                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="6%"><img src="design/ico_archive2.gif" alt="" width="9" height="11" /></td>
                    <td width="94%"><strong>jar.com<br/>
                    Job Application and Recruitment<br/>
                    Nairobi, Kenya<br/>
                    PO Box:000100-75</strong></td>
                  </tr>
                  <tr>
                    <td><img src="design/ico_archive2.gif" alt="" width="9" height="11" /></td>
					<td><strong>Office No: 091-Kilimanjaro<br/>
					Mobile: +25412345678
					</strong></td>
					
                  </tr>
                  <tr>
                    <td><img src="design/ico_archive2.gif" alt="" width="9" height="11" /></td>
                    <td><strong>Email: jar@gmail.com</strong></td>
                  </tr>
                  <tr>
                    <td><img src="design/ico_archive2.gif" alt="" width="9" height="11" /></td>
                    <td><strong>Website:jar.co.ke</strong></td>
                  </tr>
			
                </table>
				<p><img src="design/banner5.jpg" alt="" width="500" height="300" /></p>
              
              <p>&nbsp;</p>

              <p class="btn-more box noprint">&nbsp;</p>
          </div> <!-- /article -->

            <hr class="noscreen" />
            
        </div> <!-- /content -->

<?php
include "Right.php"
?>

    </div> <!-- /page-in -->
    </div> <!-- /page -->

 
<?php
include "Footer.php"
?>
</div> <!-- /main -->


</body>
</html>
