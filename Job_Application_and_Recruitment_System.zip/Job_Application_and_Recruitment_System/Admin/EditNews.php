<?php
session_start();
if(!isset($_SESSION['$UserName'])){
    header('location:../index.php');
    exit(); // Terminate script after redirection
}

// Check if NewsId is set and valid
if(isset($_GET['NewsId']) && is_numeric($_GET['NewsId'])) {
    $newsId = $_GET['NewsId'];

    // Fetch existing news details from the database
    $con = mysqli_connect("localhost", "root", "", "jar");
    $sql = "SELECT * FROM news_master WHERE NewsId = $newsId";
    $result = mysqli_query($con, $sql);
    $row = mysqli_fetch_assoc($result);

    // Check if news with the given ID exists
    if($row) {
        // Assign news details to variables
        $news = $row['News'];
        $newsDate = $row['NewsDate'];
    } else {
        // Redirect to news.php if the news with the given ID does not exist
        header('location: news.php');
        exit(); // Terminate script after redirection
    }
} else {
    // Redirect to news.php if NewsId is not set or invalid
    header('location: news.php');
    exit(); // Terminate script after redirection
}

// Check if the form is submitted for updating news
if(isset($_POST['button'])) {
    // Validate and sanitize user inputs
    $editedNews = mysqli_real_escape_string($con, $_POST['txtNews']);

    // Update the news in the database
    $updateSql = "UPDATE news_master SET News = '$editedNews' WHERE NewsId = $newsId";
    $updateResult = mysqli_query($con, $updateSql);

    // Check if the update was successful
    if($updateResult) {
        // Redirect back to news.php
        header('location: news.php');
        exit(); // Terminate script after redirection
    } else {
        // Handle error (e.g., display an error message)
        echo "Error updating news: " . mysqli_error($con);
    }
}

// Close the database connection
mysqli_close($con);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit News</title>
        <link rel="index" href="./" title="Home"/>
    <link rel="stylesheet" media="screen,projection" type="text/css" href="./css/main.css"/>
    <link rel="stylesheet" media="print" type="text/css" href="./css/print.css"/>
    <link rel="stylesheet" media="aural" type="text/css" href="./css/aural.css"/>
</head>
<body>
<center> <h2>Edit News</h2>

    <form id="editNewsForm" method="post" action="EditNews.php?NewsId=<?php echo $newsId; ?>">
        <label for="txtNews">News:</label>
        <input type="text" name="txtNews" id="txtNews" value="<?php echo $news; ?>">

        <label for="txtDate">News Date:</label>
        <input type="text" name="txtDate" id="txtDate" readonly value="<?php echo $newsDate; ?>">

        <input type="submit" name="button" value="Save Changes">
    </form>
</center>
</body>
</html>
