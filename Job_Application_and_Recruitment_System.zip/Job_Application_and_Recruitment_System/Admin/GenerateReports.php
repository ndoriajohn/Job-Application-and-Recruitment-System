<?php
session_start();
if(isset($_SESSION['$UserName'])){

} 
else{
		header('location:../index.php');
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Generate Reports</title>
    <meta name="description" content="..."/>
    <meta name="keywords" content="..."/>

    <link rel="index" href="./" title="Home"/>
    <link rel="stylesheet" media="screen,projection" type="text/css" href="./css/main.css"/>
    <link rel="stylesheet" media="print" type="text/css" href="./css/print.css"/>
    <link rel="stylesheet" media="aural" type="text/css" href="./css/aural.css"/>
    <style type="text/css">
        <!--
        .style1 {
            color: #000066;
            font-weight: bold;
        }

        .style3 {
            font-weight: bold
        }

        -->
    </style>
    <!-- Include your CSS and other head elements if needed -->
</head>
<body id="www-url-cz">
<!-- Main -->
<div id="main" class="box">
    <?php
    include "Header.php"
    ?>
    <?php
    include "Menu.php"
    ?>

<div id="content">
    <h2>Generate Reports</h2>

    <ul>
        <li><a href="GenerateReports.php?type=employers">Employer Reports</a></li>
        <li><a href="GenerateReports.php?type=jobseekers">Job Seeker Reports</a></li>
    </ul>

    <?php
    if (isset($_GET['type'])) {
        $reportType = $_GET['type'];

        if ($reportType === 'employers') {
            generateEmployerReport();
        } elseif ($reportType === 'jobseekers') {
            generateJobSeekerReport();
        } else {
            echo "Invalid report type!";
        }
    }
    ?>
<button onclick="window.location.href='GenerateReports.php'">Back</button>
 
</div>

<?php
include "Right.php";

?>

</body>
</html>

<?php

function generateEmployerReport()
{
    // Establish Connection with Database
    $con = mysqli_connect("localhost", "root", "", "jar");

    // Check connection
    if (mysqli_connect_errno()) {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
        return;
    }

    // Specify the query to execute
    $sql = "SELECT * FROM Employer_Reg";

    // Execute the query
    $result = mysqli_query($con, $sql);

    if (!$result) {
        echo "Error in SQL query: " . mysqli_error($con);
        return;
    }

    // Display the report table
    echo '<form method="post" action="DownloadEmpReport.php?type=employers">
            <table width="100%" border="1" bordercolor="#1CB5F1" name="EmployerTable">
                <tr>
                    <th height="32" bgcolor="#1CB5F1" class="style3">
                        <div align="left" class="style9 style5"><strong>Id</strong></div>
                    </th>
                    <th bgcolor="#1CB5F1" class="style3">
                        <div align="left" class="style9 style5"><strong>Company Name</strong></div>
                    </th>
                    <th bgcolor="#1CB5F1" class="style3">
                        <div align="left" class="style9 style5"><strong>City</strong></div>
                    </th>
                    <th bgcolor="#1CB5F1" class="style3">
                        <div align="left" class="style12">Contact Person</div>
                    </th>
                    <th bgcolor="#1CB5F1" class="style3">
                        <div align="left" class="style9 style5"><strong>Detail</strong></div>
                    </th>
                </tr>';

    // Loop through each record and display in the table
    while ($row = mysqli_fetch_array($result)) {
        $Id = $row['EmployerId'];
        $Name = $row['CompanyName'];
        $City = $row['City'];
        $CP = $row['ContactPerson'];

        echo '<tr>
                <td class="style3">
                    <div align="left" class="style9 style5">
                        <strong>' . $Id . '</strong>
                    </div>
                </td>
                <td class="style3">
                    <div align="left" class="style9 style5">
                        <strong>' . $Name . '</strong>
                    </div>
                </td>
                <td class="style3">
                    <div align="left" class="style9 style5">
                        <strong>' . $City . '</strong>
                    </div>
                </td>
                <td class="style3">
                    <div align="left" class="style9 style5">
                        <strong>' . $CP . '</strong>
                    </div>
                </td>
                <td class="style3">
                    <div align="left" class="style9 style5">
                        <strong>
                            <a href="DetailEmp.php?EmpId=' . $Id . '">Detail</a>
                        </strong>
                    </div>
                </td>
            </tr>';
    }

    echo '</table>
            <button type="submit" name="download">Download Employer Report</button>
          </form>';

    // Close the connection
    mysqli_close($con);
}


function generateJobSeekerReport()
{
    // Establish Connection with Database
    $con = mysqli_connect("localhost", "root", "", "jar");

    // Check connection
    if (mysqli_connect_errno()) {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
        return;
    }

    // Specify the query to execute
    $sql = "SELECT * FROM JobSeeker_Reg";

    // Execute the query
    $result = mysqli_query($con, $sql);

    if (!$result) {
        echo "Error in SQL query: " . mysqli_error($con);
        return;
    }

    // Display the report table
    echo '<form method="post" action="DownloadJobSeekerReport.php?type=jobseekers">
    <table width="100%" border="1" bordercolor="#1CB5F1" name="JobSeekerTable">
            <tr>
                <th height="32" bgcolor="#1CB5F1" class="style3">
                    <div align="left" class="style9 style5"><strong>Id</strong></div>
                </th>
                <th bgcolor="#1CB5F1" class="style3">
                    <div align="left" class="style9 style5"><strong>Name</strong></div>
                </th>
                <th bgcolor="#1CB5F1" class="style3">
                    <div align="left" class="style9 style5"><strong>Email</strong></div>
                </th>
                <th bgcolor="#1CB5F1" class="style3">
                    <div align="left" class="style12">Phone</div>
                </th>
                <th bgcolor="#1CB5F1" class="style3">
                    <div align="left" class="style9 style5"><strong>Detail</strong></div>
                </th>
            </tr>';

    // Loop through each record and display in the table
    while ($row = mysqli_fetch_array($result)) {
        $Id = $row['JobSeekId'];
        $Name = $row['JobSeekerName'];
        $Email = $row['Email'];
        $Phone = $row['Mobile'];

        echo '<tr>
                <td class="style3">
                    <div align="left" class="style9 style5">
                        <strong>' . $Id . '</strong>
                    </div>
                </td>
                <td class="style3">
                    <div align="left" class="style9 style5">
                        <strong>' . $Name . '</strong>
                    </div>
                </td>
                <td class="style3">
                    <div align="left" class="style9 style5">
                        <strong>' . $Email . '</strong>
                    </div>
                </td>
                <td class="style3">
                    <div align="left" class="style9 style5">
                        <strong>' . $Phone . '</strong>
                    </div>
                </td>
                <td class="style3">
                    <div align="left" class="style9 style5">
                        <strong>
                            <a href="DetailJob.php?JobId=' . $Id . '">Detail</a>
                        </strong>
                    </div>
                </td>
            </tr>';
    }

    echo '</table>
            <button type="submit" name="download">Download Job Seeker Report</button>
          </form>';
    // Close the connection
    mysqli_close($con);
}

include "Footer.php";
?>






