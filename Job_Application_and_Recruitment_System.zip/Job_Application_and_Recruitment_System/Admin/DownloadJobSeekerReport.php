<?php

if (isset($_GET['type']) && $_GET['type'] === 'jobseekers') {
    // Set the headers for a CSV file download
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="jobseeker_report.csv"');

    // Open a file handle for writing to php://output (output to browser)
    $output = fopen('php://output', 'w');

    // Establish Connection with Database
    $con = mysqli_connect("localhost", "root", "", "jar");

    // Check connection
    if (mysqli_connect_errno()) {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
        exit;
    }

    // Specify the query to execute
    $sql = "SELECT * FROM JobSeeker_Reg";

    // Execute the query
    $result = mysqli_query($con, $sql);

    if (!$result) {
        echo "Error in SQL query: " . mysqli_error($con);
        exit;
    }

    // Output the column headings
    $heading = array('Id', 'Name', 'Email', 'Phone');
    fputcsv($output, $heading);

    // Loop through each record and output to CSV
    while ($row = mysqli_fetch_assoc($result)) {
        fputcsv($output, $row);
    }

    // Close the file handle
    fclose($output);

    // Close the connection
    mysqli_close($con);
} else {
    // If an invalid type is provided, redirect to an error page or handle as needed
    header('Location: error.php');
}
