<?php
session_start();
if (!isset($_SESSION['$UserName_job'])) {
    header('location:../index.php');
    exit;
}

$con = mysqli_connect("localhost", "root", "", "jar");

$currentPage = $_SERVER["PHP_SELF"];

$query_Recordset1 = "SELECT MinQualification FROM job_master";
$Recordset1 = mysqli_query($con, $query_Recordset1) or die(mysqli_error());
$row_Recordset1 = mysqli_fetch_assoc($Recordset1);

$query_Recordset4 = "SELECT distinct CompanyName FROM job_master";
$Recordset4 = mysqli_query($con, $query_Recordset4) or die(mysqli_error());
$row_Recordset4 = mysqli_fetch_assoc($Recordset4);

$query_Recordset5 = "SELECT distinct JobTitle FROM job_master";
$Recordset5 = mysqli_query($con, $query_Recordset5) or die(mysqli_error());
$row_Recordset5 = mysqli_fetch_assoc($Recordset5);

$colname_Recordset2 = isset($_POST['cmbQual']) ? $_POST['cmbQual'] : "-1";
$colname2_Recordset2 = isset($_POST['cmbCompany']) ? $_POST['cmbCompany'] : "-1";
$colname3_Recordset2 = isset($_POST['cmbArea']) ? $_POST['cmbArea'] : "-1";

$keyword = isset($_POST['txtKeyword']) ? $_POST['txtKeyword'] : '';

// Check if the search form is submitted
if (isset($_POST['txtKeyword'])) {
    $keyword = mysqli_real_escape_string($con, $_POST['txtKeyword']);
    // Modify the query to include the search condition
    $query_Recordset2 = "SELECT * FROM job_master WHERE JobTitle LIKE '%$keyword%' OR MinQualification LIKE '%$keyword%'";
    $Recordset2 = mysqli_query($con, $query_Recordset2) or die(mysqli_error());
    $totalRows_Recordset2 = mysqli_num_rows($Recordset2);
} else {
    // Default query to retrieve all jobs without filters
    $query_Recordset2 = "SELECT * FROM job_master";
    $Recordset2 = mysqli_query($con, $query_Recordset2) or die(mysqli_error());
    $totalRows_Recordset2 = mysqli_num_rows($Recordset2);
}

?>

<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta http-equiv="content-language" content="cs" />
    <meta name="robots" content="all,follow" />

    
<title>Job Application and Recruitment System</title>
    <meta name="description" content="..." />
    <meta name="keywords" content="..." />
    
    <link rel="index" href="./" title="Home" />
    <link rel="stylesheet" media="screen,projection" type="text/css" href="./css/main.css" />
    <link rel="stylesheet" media="print" type="text/css" href="./css/print.css" />
    <link rel="stylesheet" media="aural" type="text/css" href="./css/aural.css" />
    <style type="text/css">
<!--
.style1 {
	color: #000066;
	font-weight: bold;
}
.style2 {font-weight: bold}
.style3 {font-weight: bold}
-->
    </style>
</head>

<body id="www-url-cz">
    <div id="main" class="box">
        <?php include "Header.php" ?>
        <?php include "Menu.php" ?>

        <div id="page" class="box">
            <div id="page-in" class="box">
                <div id="content">
                    <div class="article">
                        <h2><span><a href="#">All Jobs</a></span></h2>

                        <form method="post" action="<?php echo $currentPage; ?>">
        <label for="txtKeyword">Search Jobs:</label>
        <input type="text" name="txtKeyword" id="txtKeyword" />
        <input type="submit" value="Search" />
    </form>

                        <?php
                        
if ($totalRows_Recordset2 != 0) {
    while ($row_Recordset2 = mysqli_fetch_assoc($Recordset2)) {
?>
        <table width="100%" border="0" cellpadding="0" cellspacing="0">
            <!-- Display all job details -->
            <!-- ... -->
            <tr>
                <td><?php echo $row_Recordset2['JobTitle']; ?></td>
                <td><?php echo $row_Recordset2['CompanyName']; ?></td>
                <td><?php echo $row_Recordset2['Description']; ?></td>
                <!-- Add a button or link for users to apply -->
                <td>
                    <a href="Apply.php?JobId=<?php echo $row_Recordset2['JobId'];?>"><strong>Apply</strong></a></td>
            </tr>
            <!-- ... -->
        </table>
<?php
    }
} else {
    echo "No jobs found.";
}
?>
                    </div>
                </div>
                <?php include "Right.php" ?>
            </div>
        </div>
        <?php include "Footer.php" ?>
    </div>
</body>

</html>

<?php
mysqli_free_result($Recordset1);
mysqli_free_result($Recordset4);
mysqli_free_result($Recordset5);
mysqli_free_result($Recordset2);
?>
