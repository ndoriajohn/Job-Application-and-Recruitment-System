<?php
session_start();
if (!isset($_SESSION['$UserName_job'])) {
    header('location:../index.php');
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
     <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta http-equiv="content-language" content="cs" />
    <meta name="robots" content="all,follow" />

    
    <title>Job Application and Recruitment System</title>
    <meta name="description" content="..." />
    <meta name="keywords" content="..." />
    
    <link rel="index" href="./" title="Home" />
    <link rel="stylesheet" media="screen,projection" type="text/css" href="./css/main.css" />
    <link rel="stylesheet" media="print" type="text/css" href="./css/print.css" />
    <link rel="stylesheet" media="aural" type="text/css" href="./css/aural.css" />
    <style type="text/css">
<!--
.style1 {
	color: #000066;
	font-weight: bold;
}
.style3 {font-weight: bold}
-->
    </style>
</head>
<body id="www-url-cz">
<!-- Main -->
<div id="main" class="box">
    <?php include "Header.php" ?>
    <?php include "Menu.php" ?>

    <!-- Page (2 columns) -->
    <div id="page" class="box">
        <div id="page-in" class="box">
            <div id="strip" class="box noprint">
                <!-- your strip content here -->
            </div> <!-- /strip -->

            <!-- Content -->
            <div id="content">
                <!-- your content here -->

                <!-- Article -->
                <div class="article">
                    <h2><span><a href="#">CALL LETTERS</a></span></h2>

                    <?php
                    // Establish Connection with MYSQL
                    $con = mysqli_connect("localhost", "root", "", "jar");

                    // Specify the query to fetch the call letter details
                    $sql = "SELECT * FROM Application_Master WHERE ApplicationId = ? AND JobId = ? AND JobSeekId = ?";
                    $stmt = mysqli_prepare($con, $sql);
                    mysqli_stmt_bind_param($stmt, "iss", $AppId, $JobId, $JobSeekId);
                    mysqli_stmt_execute($stmt);
                    $result = mysqli_stmt_get_result($stmt);

                    // Check if the record exists
                    if ($row = mysqli_fetch_assoc($result)) {
                        // Display call letter details
                        $status = $row['Status'];
                        $description = $row['Description'];

                        echo "<html>";
                        echo "<head><title>Call Letter Details</title></head>";
                        echo "<body>";
                        echo "<h2>Call Letter Details</h2>";
                        echo "<p>Status: $status</p>";
                        echo "<p>Description: $description</p>";
                        echo "<p><a href='index.php'>Back to Home</a></p>";
                        echo "</body>";
                        echo "</html>";
                    } else {
                        echo "Call letter not found.";
                    }

                    // Close The Connection
                    mysqli_close($con);
                    ?>
                </div>
            </div> <!-- /content -->
        </div> <!-- /page-in -->
    </div> <!-- /page -->
</div> <!-- /main -->
</body>
</html>
