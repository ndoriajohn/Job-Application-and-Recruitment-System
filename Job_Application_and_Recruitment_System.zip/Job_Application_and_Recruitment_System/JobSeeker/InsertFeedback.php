<!DOCTYPE>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php
if(!isset($_SESSION))
{
session_start();
}
	$FeedBack=$_POST['txtFeedback'];
	$FDate= date('y/m/d');
	$Id=$_SESSION['ID'];
	
	
	
	// Establish Connection with MYSQL
	$con = mysqli_connect ("localhost","root","","jar");

	// Specify the query to Insert Record
	$sql = "insert into Feedback(JobSeekId,Feedback,FeedbakDate) values('".$Id."','".$FeedBack."','".$FDate."')";
	// execute query
	 var_dump($sql);
	if(mysqli_query ($con,$sql)){



        echo '<script type="text/javascript">alert("Feedback Sent Succesfully");window.location=\'index.php\';</script>';
    }
      
	
	// Close The Connection
	mysqli_close ($con);
	
	

?>
</body>
</html>
