if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $callLetterDesc = $_POST["txtDesc"];
    
    // Assuming JobSeekId is available (e.g., passed in the form or retrieved from a session)
    $jobSeekId = isset($_POST["JobSeekId"]) ? $_POST["JobSeekId"] : null;

    // Ensure that JobSeekId is not null before proceeding
    if ($jobSeekId !== null) {
        // Establish Connection with Database
        $con = mysqli_connect("localhost", "root", "", "jar");

        // Check the connection
        if (!$con) {
            die("Connection failed: " . mysqli_connect_error());
        }        // Update the Application_master table
        $updateSql = "UPDATE Application_master SET Status = 'Call Letter Sent', Description = ? WHERE JobSeekId = ?";


        // Update the Application_master table
        $updateSql = "UPDATE Application_master SET Status = 'Call Letter Sent', Description = ? WHERE JobSeekId = ?";

        $stmt = mysqli_prepare($con, $updateSql);

        // Check if the statement was prepared successfully before binding parameters
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "si", $callLetterDesc, $jobSeekId);

            // Execute the update query
            if (mysqli_stmt_execute($stmt)) {
                echo "Call letter sent successfully for JobSeekId: $jobSeekId.";
            } else {
                echo "Error updating record: " . mysqli_error($con);
            }

            // Close the statement
            mysqli_stmt_close($stmt);
        } else {
            echo "Error preparing statement: " . mysqli_error($con);
        }

        // Close the connection
        mysqli_close($con);
    } else {
        echo "JobSeekId is not set in the form.";
    }
}
?>
