<?php
if (!isset($_SESSION)) {
    session_start();
}

// Check if the user is logged in
if (!isset($_SESSION['ID'])) {
    header("Location: login.php"); // Redirect to login page if not logged in
    exit();
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $id = $_POST['txtId'];
    $name = $_POST['txtName'];
    $contact = $_POST['txtContact'];
    $address = $_POST['txtAddress'];
    $city = $_POST['txtCity'];
    $email = $_POST['txtEmail'];
    $mobile = $_POST['txtMobile'];
    $area = $_POST['txtArea'];
    $username = $_POST['txtUser'];
    $password = $_POST['txtPassword'];

    // Establish Connection with Database
    $con = mysqli_connect("localhost", "root", "", "jar");

    // Update the user profile in the database
    $updateSql = "UPDATE Employer_Reg SET
        CompanyName = '$name',
        ContactPerson = '$contact',
        Address = '$address',
        City = '$city',
        Email = '$email',
        Mobile = '$mobile',
        Area_Work = '$area',
        UserName = '$username',
        Password = '$password'
        WHERE EmployerId = '$id'";

    $updateResult = mysqli_query($con, $updateSql);

    // Check if the update was successful
    if ($updateResult) {
        echo "Profile updated successfully.";
    } else {
        echo "Error updating profile: " . mysqli_error($con);
    }

    // Close the database connection
   mysqli_close($con);
echo '<script type="text/javascript">alert(" Profile Updated Succesfully");window.location=\'Profile.php\';</script>';
}
?>





