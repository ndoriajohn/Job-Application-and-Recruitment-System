<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_jar = "localhost";
$database_jar='jar';
$username_jar = "root";
$password_jar = "";
$jar;
$database_jar = mysqli_connect($hostname_jar, $username_jar, $password_jar,"jar") or trigger_error(mysqli_error(),E_USER_ERROR);





?>